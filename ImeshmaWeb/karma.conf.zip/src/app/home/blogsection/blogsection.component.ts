import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogsection',
  templateUrl: './blogsection.component.html',
  styleUrls: ['./blogsection.component.css']
})
export class BlogsectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
