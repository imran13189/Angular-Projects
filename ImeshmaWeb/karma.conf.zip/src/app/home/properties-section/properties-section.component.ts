import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-properties-section',
  templateUrl: './properties-section.component.html',
  styleUrls: ['./properties-section.component.css']
})
export class PropertiesSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
